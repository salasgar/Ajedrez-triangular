// script.js — Interfaz: dibujo del tablero en SVG e interacción.

const SVG_NS = 'http://www.w3.org/2000/svg';

const boardWrap = document.getElementById('board-wrap');
const turnEl = document.getElementById('turn');
const statusEl = document.getElementById('status');
const capWEl = document.getElementById('cap-w');
const capBEl = document.getElementById('cap-b');
const btnStart = document.getElementById('btn-start');
const btnUndo = document.getElementById('btn-undo');
const btnRedo = document.getElementById('btn-redo');
const btnEnd = document.getElementById('btn-end');
const btnRandom = document.getElementById('btn-random');
const randNEl = document.getElementById('rand-n');
const modeEl = document.getElementById('mode');
const levelWEl = document.getElementById('level-w');
const levelBEl = document.getElementById('level-b');
const rowLevelW = document.getElementById('row-level-w');
const rowLevelB = document.getElementById('row-level-b');
const saveSelect = document.getElementById('save-select');
const btnSave = document.getElementById('btn-save');
const btnLoad = document.getElementById('btn-load');
const btnDelete = document.getElementById('btn-delete');
const btnExport = document.getElementById('btn-export');
const btnImport = document.getElementById('btn-import');
const fileImport = document.getElementById('file-import');

const cellPolys = new Map();  // key de casilla → <polygon>
let piecesLayer = null;
let selected = null;          // key de la casilla seleccionada
let legalTargets = [];        // casillas destino legales de la selección

function buildSvg() {
  const svg = document.createElementNS(SVG_NS, 'svg');
  svg.setAttribute('viewBox', `${BBOX.x} ${BBOX.y} ${BBOX.w} ${BBOX.h}`);

  const cellsLayer = document.createElementNS(SVG_NS, 'g');
  for (const cell of CELLS) {
    const poly = document.createElementNS(SVG_NS, 'polygon');
    poly.setAttribute('points', cell.pts.map(p => p.join(',')).join(' '));
    poly.classList.add('cell', cell.up ? 'light' : 'dark');
    poly.addEventListener('click', () => onCellClick(cell));
    cellsLayer.appendChild(poly);
    cellPolys.set(cell.key, poly);
  }
  piecesLayer = document.createElementNS(SVG_NS, 'g');
  svg.appendChild(cellsLayer);
  svg.appendChild(piecesLayer);
  boardWrap.appendChild(svg);
}

function onCellClick(cell) {
  if (gameEnded()) return;
  if (aiConfig[game.turn] !== null) return;   // le toca al ordenador

  if (selected && legalTargets.some(t => t.key === cell.key)) {
    makeMove(selected, cell.key);
    selected = null;
    legalTargets = [];
    render();
    scheduleAi();
    return;
  }
  const piece = game.board.get(cell.key);
  if (piece && piece.color === game.turn && cell.key !== selected) {
    selected = cell.key;
    legalTargets = legalMoves(game.board, cell.key, piece);
  } else {
    selected = null;
    legalTargets = [];
  }
  render();
}

function render() {
  for (const poly of cellPolys.values()) {
    poly.classList.remove('selected', 'legal', 'capture', 'last-move', 'in-check');
  }
  if (game.lastMove) {
    cellPolys.get(game.lastMove.from).classList.add('last-move');
    cellPolys.get(game.lastMove.to).classList.add('last-move');
  }
  if (selected) cellPolys.get(selected).classList.add('selected');
  for (const t of legalTargets) {
    cellPolys.get(t.key).classList.add(game.board.get(t.key) ? 'capture' : 'legal');
  }
  if (game.status === 'check' || game.status === 'checkmate') {
    const king = findKing(game.board, game.turn);
    if (king) cellPolys.get(king.key).classList.add('in-check');
  }

  piecesLayer.innerHTML = '';
  for (const [key, p] of game.board) {
    const cell = CELL_MAP.get(key);
    const text = document.createElementNS(SVG_NS, 'text');
    text.setAttribute('x', cell.cx);
    text.setAttribute('y', cell.cy);
    text.setAttribute('class',
      `piece piece-${p.type} ` + (p.color === 'w' ? 'piece-w' : 'piece-b'));
    text.textContent = GLYPH[p.type];
    piecesLayer.appendChild(text);
  }

  const names = { w: 'blancas', b: 'negras' };
  if (game.status === 'checkmate') {
    turnEl.textContent = 'Fin de la partida';
    statusEl.textContent = `¡Jaque mate! Ganan las ${names[game.winner]}.`;
  } else if (game.status === 'stalemate') {
    turnEl.textContent = 'Fin de la partida';
    statusEl.textContent = 'Tablas por ahogado.';
  } else if (game.status === 'repetition') {
    turnEl.textContent = 'Fin de la partida';
    statusEl.textContent = 'Tablas por triple repetición.';
  } else if (game.status === 'fifty') {
    turnEl.textContent = 'Fin de la partida';
    statusEl.textContent = 'Tablas por la regla de los 50 movimientos.';
  } else {
    turnEl.textContent = `Juegan las ${names[game.turn]}`;
    let msg = game.status === 'check' ? '¡Jaque!' : '';
    if (isAiTurn() && atHistoryEnd()) {
      msg += (msg ? ' ' : '') + 'El ordenador piensa…';
    }
    statusEl.textContent = msg;
  }
  capWEl.textContent = game.capturedBy.w.map(p => GLYPH[p.type]).join(' ');
  capBEl.textContent = game.capturedBy.b.map(p => GLYPH[p.type]).join(' ');

  btnStart.disabled = btnUndo.disabled = game.histIndex === 0;
  btnRedo.disabled = btnEnd.disabled = game.histIndex === game.history.length - 1;
  btnRandom.disabled = gameEnded();
}

function clearSelection() {
  selected = null;
  legalTargets = [];
}

// --- modos de juego y turno del ordenador ---

// Quién controla cada color: null = humano, o nivel 1..7 del ordenador.
const aiConfig = { w: null, b: null };
let aiToken = 0;   // invalida los timers y búsquedas pendientes de la IA

function atHistoryEnd() { return game.histIndex === game.history.length - 1; }
function gameOver() { return gameEnded(); }
function isAiTurn() { return aiConfig[game.turn] !== null && !gameOver(); }
function cancelAi() { aiToken++; abortAiSearch(); }

// Si le toca al ordenador (y estamos al final del historial), juega tras una
// pequeña pausa. La búsqueda corre en un worker (ai-async.js), así que la
// interfaz sigue viva mientras piensa; el token invalida el resultado si
// entre tanto el usuario deshizo, cargó otra partida, etc.
// En ordenador vs ordenador se encadena solo hasta el final.
function scheduleAi() {
  if (!isAiTurn() || !atHistoryEnd()) return;
  const token = aiToken;
  setTimeout(() => {
    if (token !== aiToken || !isAiTurn() || !atHistoryEnd()) return;
    requestAiMove(aiConfig[game.turn], (mv) => {
      if (token !== aiToken || !isAiTurn() || !atHistoryEnd()) return;
      if (!mv) return;
      makeMove(mv.from, mv.to);
      render();
      scheduleAi();
    });
  }, 400);
}

function applyModeFromUI() {
  const m = modeEl.value;
  aiConfig.w = (m === 'ch' || m === 'cc') ? parseInt(levelWEl.value, 10) : null;
  aiConfig.b = (m === 'hc' || m === 'cc') ? parseInt(levelBEl.value, 10) : null;
  rowLevelW.classList.toggle('hidden', aiConfig.w === null);
  rowLevelB.classList.toggle('hidden', aiConfig.b === null);
  cancelAi();
  clearSelection();
  render();
  scheduleAi();
}

modeEl.addEventListener('change', applyModeFromUI);
levelWEl.addEventListener('change', applyModeFromUI);
levelBEl.addEventListener('change', applyModeFromUI);

btnStart.addEventListener('click', () => { cancelAi(); goToStart(); clearSelection(); render(); scheduleAi(); });
btnUndo.addEventListener('click', () => {
  cancelAi();
  undoMove();
  // contra el ordenador se deshace el par: su respuesta y la jugada humana
  const oneAi = (aiConfig.w === null) !== (aiConfig.b === null);
  if (oneAi && aiConfig[game.turn] !== null && game.histIndex > 0) undoMove();
  clearSelection();
  render();
});
btnRedo.addEventListener('click', () => { cancelAi(); redoMove(); clearSelection(); render(); scheduleAi(); });
btnEnd.addEventListener('click', () => { cancelAi(); goToEnd(); clearSelection(); render(); scheduleAi(); });
btnRandom.addEventListener('click', () => {
  cancelAi();
  const n = Math.min(500, Math.max(1, parseInt(randNEl.value, 10) || 1));
  randomMoves(n);
  clearSelection();
  render();
  scheduleAi();
});

document.getElementById('new-game').addEventListener('click', () => {
  cancelAi();
  newGame();
  clearSelection();
  render();
  scheduleAi();
});

// --- guardar y cargar partidas ---

function refreshSaveList(selectedName) {
  saveSelect.innerHTML = '';
  const empty = document.createElement('option');
  empty.value = '';
  empty.textContent = '— ninguna —';
  saveSelect.appendChild(empty);
  for (const { name, savedAt } of listSaves()) {
    const opt = document.createElement('option');
    opt.value = name;
    const date = savedAt
      ? new Date(savedAt).toLocaleString('es-ES', { dateStyle: 'short', timeStyle: 'short' })
      : '';
    opt.textContent = date ? `${name} · ${date}` : name;
    saveSelect.appendChild(opt);
  }
  if (selectedName) saveSelect.value = selectedName;
  btnLoad.disabled = btnDelete.disabled = !saveSelect.value;
}

function currentEnvelope() {
  return serializeGame(modeEl.value, levelWEl.value, levelBEl.value);
}

function loadEnvelope(data) {
  cancelAi();
  applySave(data);
  modeEl.value = data.mode;
  levelWEl.value = data.levelW;
  levelBEl.value = data.levelB;
  applyModeFromUI();   // ya hace cancelAi + clearSelection + render + scheduleAi
}

saveSelect.addEventListener('change', () => {
  btnLoad.disabled = btnDelete.disabled = !saveSelect.value;
});

btnSave.addEventListener('click', () => {
  const name = (prompt('Nombre de la partida:', saveSelect.value || '') || '').trim();
  if (!name) return;
  if (localStorage.getItem(SAVE_PREFIX + name) !== null &&
      !confirm(`Ya existe una partida llamada «${name}». ¿Sobrescribirla?`)) return;
  if (!saveToStorage(name, currentEnvelope())) {
    alert('No se pudo guardar la partida (almacenamiento lleno).');
  } else {
    refreshSaveList(name);
  }
});

btnLoad.addEventListener('click', () => {
  const name = saveSelect.value;
  if (!name) return;
  const data = loadFromStorage(name);
  if (!data) {
    alert('No se pudo cargar la partida: datos dañados o incompatibles.');
    return;
  }
  loadEnvelope(data);
});

btnDelete.addEventListener('click', () => {
  const name = saveSelect.value;
  if (!name) return;
  if (!confirm(`¿Borrar la partida «${name}»?`)) return;
  deleteFromStorage(name);
  refreshSaveList();
});

btnExport.addEventListener('click', () => {
  const stamp = new Date().toISOString().slice(0, 16).replace(/[T:]/g, '-');
  downloadSave(currentEnvelope(), `ajedrez-triangular-${stamp}.json`);
});

btnImport.addEventListener('click', () => {
  fileImport.value = '';
  fileImport.click();
});

fileImport.addEventListener('change', () => {
  const file = fileImport.files[0];
  if (!file) return;
  readSaveFile(file, loadEnvelope,
    () => alert('El archivo no es una partida válida de Ajedrez Triangular.'));
});

// --- miniaturas de movimientos en el panel de reglas ---

// Tablero pequeño no interactivo: piezas = [key, tipo, color] (la casilla de
// la primera pieza blanca queda resaltada), blueKeys = casillas a las que
// puede moverse, capKeys = capturas del peón.
function makeMini(pieces, blueKeys, capKeys) {
  const svg = document.createElementNS(SVG_NS, 'svg');
  svg.setAttribute('viewBox', `${BBOX.x} ${BBOX.y} ${BBOX.w} ${BBOX.h}`);
  svg.setAttribute('class', 'mini-board');
  const ownKeys = new Set(pieces.filter(p => p[2] === 'w').map(p => p[0]));
  for (const cell of CELLS) {
    const poly = document.createElementNS(SVG_NS, 'polygon');
    poly.setAttribute('points', cell.pts.map(p => p.join(',')).join(' '));
    poly.classList.add('cell', cell.up ? 'light' : 'dark');
    if (ownKeys.has(cell.key)) poly.classList.add('selected');
    if (blueKeys.has(cell.key)) poly.classList.add('legal');
    if (capKeys && capKeys.has(cell.key)) poly.classList.add('capture');
    svg.appendChild(poly);
  }
  for (const [key, type, color] of pieces) {
    const cell = CELL_MAP.get(key);
    const text = document.createElementNS(SVG_NS, 'text');
    text.setAttribute('x', cell.cx);
    text.setAttribute('y', cell.cy);
    text.setAttribute('class',
      `piece piece-${type} ` + (color === 'w' ? 'piece-w' : 'piece-b'));
    text.textContent = GLYPH[type];
    svg.appendChild(text);
  }
  return svg;
}

function buildRuleMinis() {
  const c = getCell(1, 0, 1);  // ▲ central, con tablero vacío alrededor
  const flat = rays => rays.flat().map(t => t.key);
  const sets = {
    R: flat(c.rookRays),
    B: flat(c.bishopRays),
    Q: flat(c.rookRays).concat(flat(c.elephantRays)),
    N: c.knightTargets.map(t => t.key),
    E: flat(c.elephantRays),
    K: c.kingNbrs.map(t => t.key),
  };
  for (const [type, keys] of Object.entries(sets)) {
    const li = document.querySelector(`#help li[data-piece="${type}"]`);
    li.appendChild(makeMini([[c.key, type, 'w']], new Set(keys)));
  }
  // Peón: uno de cada orientación, con peones negros en sus capturas
  const pUp = getCell(-1, 0, 3), pDown = getCell(2, 0, -1);
  const adv = new Set([...pUp.pawnAdv.w, ...pDown.pawnAdv.w].map(t => t.key));
  const cap = new Set([...pUp.pawnCap.w, ...pDown.pawnCap.w].map(t => t.key));
  const pieces = [[pUp.key, 'P', 'w'], [pDown.key, 'P', 'w']];
  for (const key of cap) pieces.push([key, 'P', 'b']);
  const liP = document.querySelector('#help li[data-piece="P"]');
  liP.appendChild(makeMini(pieces, adv, cap));
}

buildSvg();
buildRuleMinis();
newGame();
render();
applyModeFromUI();
refreshSaveList();

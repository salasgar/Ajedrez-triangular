// ai.js — Jugador automático con varios niveles de capacidad.
//
// Trabaja siempre sobre copias del tablero (Map) y con un estado de captura
// al paso explícito, sin tocar el objeto global `game` salvo para leerlo
// en chooseAiMove.

const PIECE_VALUE = { P: 100, N: 300, B: 330, E: 350, R: 500, Q: 900, K: 0 };
const MATE = 100000;

// Las tablas se puntúan como ceder una fracción de la ventaja material: el
// bando que va ganando las rehúye (tanto más cuanto mayor sea su ventaja,
// hasta el tope) y el que va perdiendo las busca.
const DRAW_CONTEMPT = 0.3;
const DRAW_CAP = 500;

function drawScore(board, color) {
  let m = 0;
  for (const [, p] of board) m += (p.color === color ? 1 : -1) * PIECE_VALUE[p.type];
  return Math.max(-DRAW_CAP, Math.min(DRAW_CAP, Math.round(-DRAW_CONTEMPT * m)));
}

// nivel → configuración de búsqueda
const AI_LEVELS = {
  1: { random: true },                          // al azar
  2: { depth: 1 },                              // codicioso (material inmediato)
  3: { depth: 2 },                              // minimax + alfa-beta
  4: { depth: 3, mobility: true, order: true }, // + ordenación y movilidad
  5: { depth: 4, mobility: true, order: true },
  6: { depth: 5, mobility: true, order: true },
  7: { depth: 6, mobility: true, order: true }, // lento
};

// Todas las jugadas legales de un color: [{from, to}].
function movesForSide(board, color, ep) {
  const out = [];
  for (const [key, p] of board) {
    if (p.color !== color) continue;
    for (const t of legalMoves(board, key, p, ep)) out.push({ from: key, to: t.key });
  }
  return out;
}

// Aplica una jugada sobre el Map dado (mutándolo), replicando los efectos de
// tablero de makeMove: captura al paso, promoción a dama y doble avance de
// peón. Devuelve el nuevo estado de captura al paso ({targetKey, pawnKey} o
// null). No mutar las piezas originales: los Maps copiados las comparten.
function applyMoveSim(board, fromKey, toKey, ep) {
  const piece = board.get(fromKey);
  const fromCell = CELL_MAP.get(fromKey);
  const toCell = CELL_MAP.get(toKey);

  if (piece.type === 'P' && !board.get(toKey) && ep && toKey === ep.targetKey) {
    board.delete(ep.pawnKey);
  }
  board.delete(fromKey);
  const moved = { ...piece, moved: true };
  if (moved.type === 'P' &&
    ((moved.color === 'w' && toCell.b === N) ||
      (moved.color === 'b' && toCell.b === 1 - N))) {
    moved.type = 'Q';
  }
  board.set(toKey, moved);
  return (piece.type === 'P' && Math.abs(toCell.b - fromCell.b) === 2)
    ? { targetKey: fromCell.pawnAdv[piece.color][0].key, pawnKey: toKey }
    : null;
}

// Material (y movilidad, según nivel) desde el punto de vista de `color`.
function evaluate(board, color, cfg) {
  let score = 0;
  for (const [key, p] of board) {
    const sign = p.color === color ? 1 : -1;
    score += sign * PIECE_VALUE[p.type];
    if (cfg.mobility) {
      score += sign * 2 * pseudoMoves(board, CELL_MAP.get(key), p, null).length;
    }
  }
  return score;
}

// capturas primero, la pieza más valiosa antes
function orderMoves(board, moves) {
  const gain = m => { const v = board.get(m.to); return v ? PIECE_VALUE[v.type] : -1; };
  moves.sort((m1, m2) => gain(m2) - gain(m1));
}

// `clock` son las medias jugadas sin captura ni peón; `keys` es un Map con
// las posiciones ya vistas (historial real + camino de búsqueda actual).
function negamax(board, color, ep, clock, keys, depth, alpha, beta, cfg) {
  // tablas por la regla de los 50 movimientos
  if (clock >= 100) return drawScore(board, color);
  // repetición: ver una posición por segunda vez ya se puntúa como tablas
  // (basta para detectar perpetuos con poca profundidad); solo puede darse
  // tras al menos 4 medias jugadas reversibles, de ahí la guarda
  const key = clock >= 4 ? positionKey(board, color, ep) : null;
  if (key && keys.has(key)) return drawScore(board, color);

  // en las hojas se evalúa directamente (generar los movimientos legales es
  // lo más caro; los mates se detectan igualmente un nivel antes)
  if (depth === 0) return evaluate(board, color, cfg);

  const moves = movesForSide(board, color, ep);
  if (moves.length === 0) {
    const king = findKing(board, color);
    // mate (los más rápidos puntúan más) o tablas por ahogado
    return isAttacked(board, king, rival(color)) ? -MATE - depth : drawScore(board, color);
  }
  if (cfg.order) orderMoves(board, moves);
  // registrar la posición para que las líneas descendientes la detecten
  const myKey = key || positionKey(board, color, ep);
  keys.set(myKey, (keys.get(myKey) || 0) + 1);
  let best = -Infinity;
  for (const m of moves) {
    const copy = new Map(board);
    const nextClock = (board.get(m.to) || board.get(m.from).type === 'P') ? 0 : clock + 1;
    const nextEp = applyMoveSim(copy, m.from, m.to, ep);
    const score = -negamax(copy, rival(color), nextEp, nextClock, keys, depth - 1,
      -beta, -alpha, cfg);
    if (score > best) best = score;
    if (best > alpha) alpha = best;
    if (alpha >= beta) break;
  }
  const n = keys.get(myKey) - 1;
  if (n > 0) keys.set(myKey, n); else keys.delete(myKey);
  return best;
}

// Estado mínimo que necesita la búsqueda, extraído de `game`. Es también lo
// que viaja al worker de ai-async.js, por lo que solo contiene datos
// clonables (el Map del tablero, escalares y claves de posición).
function searchState() {
  const posKeys = [];
  for (let i = 0; i <= game.histIndex; i++) posKeys.push(game.history[i].posKey);
  return { board: game.board, turn: game.turn, enPassant: game.enPassant,
           clock: game.clock, posKeys };
}

// Elige la jugada del ordenador según el nivel, para la posición actual o
// para el estado `st` dado. Devuelve {from, to} o null si no hay jugadas.
function chooseAiMove(level, st = searchState()) {
  const cfg = AI_LEVELS[level] || AI_LEVELS[1];
  const moves = movesForSide(st.board, st.turn, st.enPassant);
  if (moves.length === 0) return null;
  if (cfg.random) return moves[Math.floor(Math.random() * moves.length)];
  if (cfg.order) orderMoves(st.board, moves);

  // posiciones ya vistas en la partida, para las repeticiones en la búsqueda
  const keys = new Map();
  for (const k of st.posKeys) keys.set(k, (keys.get(k) || 0) + 1);

  // bucle raíz: acumula las jugadas empatadas a mejor puntuación y elige
  // una al azar entre ellas, para dar variedad a las partidas
  let best = -Infinity;
  let bestMoves = [];
  for (const m of moves) {
    const copy = new Map(st.board);
    const nextClock = (st.board.get(m.to) || st.board.get(m.from).type === 'P')
      ? 0 : st.clock + 1;
    const nextEp = applyMoveSim(copy, m.from, m.to, st.enPassant);
    const score = -negamax(copy, rival(st.turn), nextEp, nextClock, keys,
      cfg.depth - 1, -Infinity, -best + 1, cfg);
    if (score > best) { best = score; bestMoves = [m]; }
    else if (score === best) bestMoves.push(m);
  }
  return bestMoves[Math.floor(Math.random() * bestMoves.length)];
}
